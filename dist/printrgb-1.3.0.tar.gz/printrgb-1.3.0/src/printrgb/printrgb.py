import types
import random
import shutil
from typing import Literal
from typing import TextIO

# const
rainbow_color = [
    (237, 138, 171),
    (238, 138, 169),
    (238, 138, 168),
    (239, 138, 166),
    (239, 138, 165),
    (239, 138, 163),
    (240, 138, 162),
    (240, 138, 160),
    (240, 138, 159),
    (240, 138, 157),
    (241, 139, 156),
    (241, 139, 154),
    (241, 139, 153),
    (241, 139, 151),
    (242, 139, 150),
    (242, 139, 149),
    (242, 139, 147),
    (242, 139, 146),
    (242, 139, 144),
    (242, 139, 143),
    (242, 140, 141),
    (242, 140, 140),
    (242, 140, 138),
    (242, 140, 137),
    (242, 140, 135),
    (242, 141, 134),
    (242, 141, 132),
    (242, 141, 131),
    (242, 141, 129),
    (242, 141, 128),
    (242, 142, 127),
    (242, 142, 125),
    (242, 142, 124),
    (242, 143, 122),
    (242, 143, 121),
    (241, 143, 119),
    (241, 143, 118),
    (241, 144, 117),
    (241, 144, 115),
    (240, 144, 114),
    (240, 145, 112),
    (240, 145, 111),
    (240, 145, 110),
    (239, 146, 108),
    (239, 146, 107),
    (239, 147, 106),
    (238, 147, 104),
    (238, 147, 103),
    (237, 148, 102),
    (237, 148, 101),
    (236, 149, 99),
    (236, 149, 98),
    (235, 150, 97),
    (235, 150, 96),
    (234, 150, 94),
    (234, 151, 93),
    (233, 151, 92),
    (233, 152, 91),
    (232, 152, 90),
    (232, 153, 89),
    (231, 153, 88),
    (230, 154, 86),
    (230, 154, 85),
    (229, 155, 84),
    (228, 155, 83),
    (228, 156, 82),
    (227, 156, 82),
    (226, 157, 81),
    (225, 157, 80),
    (224, 158, 79),
    (224, 158, 78),
    (223, 159, 77),
    (222, 160, 77),
    (221, 160, 76),
    (220, 161, 75),
    (219, 161, 74),
    (218, 162, 74),
    (218, 162, 73),
    (217, 163, 73),
    (216, 163, 72),
    (215, 164, 72),
    (214, 164, 71),
    (213, 165, 71),
    (212, 166, 71),
    (211, 166, 71),
    (210, 167, 70),
    (209, 167, 70),
    (207, 168, 70),
    (206, 168, 70),
    (205, 169, 70),
    (204, 169, 70),
    (203, 170, 70),
    (202, 171, 70),
    (201, 171, 70),
    (199, 172, 70),
    (198, 172, 71),
    (197, 173, 71),
    (196, 173, 71),
    (195, 174, 72),
    (193, 174, 72),
    (192, 175, 73),
    (191, 175, 73),
    (189, 176, 74),
    (188, 177, 74),
    (187, 177, 75),
    (185, 178, 76),
    (184, 178, 76),
    (183, 179, 77),
    (181, 179, 78),
    (180, 180, 79),
    (178, 180, 80),
    (177, 181, 81),
    (175, 181, 81),
    (174, 182, 82),
    (173, 182, 83),
    (171, 183, 84),
    (170, 183, 85),
    (168, 184, 87),
    (166, 184, 88),
    (165, 184, 89),
    (163, 185, 90),
    (162, 185, 91),
    (160, 186, 92),
    (159, 186, 93),
    (157, 187, 95),
    (155, 187, 96),
    (154, 188, 97),
    (152, 188, 98),
    (150, 188, 100),
    (149, 189, 101),
    (147, 189, 102),
    (145, 190, 104),
    (144, 190, 105),
    (142, 190, 106),
    (140, 191, 108),
    (138, 191, 109),
    (137, 191, 111),
    (135, 192, 112),
    (133, 192, 113),
    (131, 192, 115),
    (130, 193, 116),
    (128, 193, 118),
    (126, 193, 119),
    (124, 194, 121),
    (122, 194, 122),
    (120, 194, 124),
    (118, 195, 125),
    (117, 195, 127),
    (115, 195, 128),
    (113, 195, 130),
    (111, 196, 131),
    (109, 196, 133),
    (107, 196, 134),
    (105, 196, 136),
    (103, 196, 137),
    (101, 197, 139),
    (99, 197, 140),
    (97, 197, 142),
    (95, 197, 143),
    (93, 197, 145),
    (91, 198, 146),
    (89, 198, 148),
    (87, 198, 149),
    (85, 198, 151),
    (83, 198, 152),
    (81, 198, 154),
    (79, 198, 155),
    (77, 198, 157),
    (75, 199, 159),
    (73, 199, 160),
    (71, 199, 162),
    (69, 199, 163),
    (67, 199, 165),
    (65, 199, 166),
    (63, 199, 168),
    (60, 199, 169),
    (58, 199, 171),
    (56, 199, 172),
    (54, 199, 174),
    (52, 199, 175),
    (50, 199, 177),
    (48, 199, 178),
    (46, 199, 180),
    (44, 199, 181),
    (42, 199, 182),
    (40, 199, 184),
    (38, 199, 185),
    (36, 199, 187),
    (34, 198, 188),
    (32, 198, 190),
    (31, 198, 191),
    (29, 198, 192),
    (27, 198, 194),
    (26, 198, 195),
    (25, 198, 197),
    (24, 198, 198),
    (23, 197, 199),
    (22, 197, 201),
    (21, 197, 202),
    (21, 197, 203),
    (21, 197, 205),
    (21, 196, 206),
    (22, 196, 207),
    (22, 196, 208),
    (23, 196, 210),
    (24, 196, 211),
    (25, 195, 212),
    (26, 195, 213),
    (28, 195, 215),
    (29, 195, 216),
    (31, 194, 217),
    (33, 194, 218),
    (35, 194, 219),
    (36, 193, 220),
    (38, 193, 222),
    (40, 193, 223),
    (42, 193, 224),
    (44, 192, 225),
    (46, 192, 226),
    (48, 192, 227),
    (50, 191, 228),
    (52, 191, 229),
    (54, 191, 230),
    (56, 190, 231),
    (58, 190, 232),
    (60, 189, 233),
    (62, 189, 234),
    (64, 189, 234),
    (66, 188, 235),
    (68, 188, 236),
    (70, 187, 237),
    (72, 187, 238),
    (74, 187, 239),
    (76, 186, 239),
    (78, 186, 240),
    (80, 185, 241),
    (82, 185, 242),
    (84, 185, 242),
    (86, 184, 243),
    (88, 184, 244),
    (90, 183, 244),
    (92, 183, 245),
    (94, 182, 245),
    (96, 182, 246),
    (97, 181, 247),
    (99, 181, 247),
    (101, 181, 248),
    (103, 180, 248),
    (105, 180, 249),
    (107, 179, 249),
    (109, 179, 249),
    (110, 178, 250),
    (112, 178, 250),
    (114, 177, 251),
    (116, 177, 251),
    (117, 176, 251),
    (119, 176, 251),
    (121, 175, 252),
    (123, 175, 252),
    (124, 174, 252),
    (126, 174, 252),
    (128, 173, 252),
    (129, 173, 253),
    (131, 172, 253),
    (133, 172, 253),
    (135, 171, 253),
    (136, 171, 253),
    (138, 170, 253),
    (139, 170, 253),
    (141, 169, 253),
    (143, 169, 253),
    (144, 168, 253),
    (146, 168, 253),
    (147, 167, 253),
    (149, 167, 252),
    (151, 166, 252),
    (152, 166, 252),
    (154, 165, 252),
    (155, 165, 252),
    (157, 164, 251),
    (158, 164, 251),
    (160, 163, 251),
    (161, 163, 250),
    (163, 162, 250),
    (164, 162, 250),
    (165, 162, 249),
    (167, 161, 249),
    (168, 161, 248),
    (170, 160, 248),
    (171, 160, 248),
    (172, 159, 247),
    (174, 159, 246),
    (175, 158, 246),
    (177, 158, 245),
    (178, 157, 245),
    (179, 157, 244),
    (181, 156, 244),
    (182, 156, 243),
    (183, 155, 242),
    (184, 155, 242),
    (186, 155, 241),
    (187, 154, 240),
    (188, 154, 239),
    (189, 153, 239),
    (191, 153, 238),
    (192, 152, 237),
    (193, 152, 236),
    (194, 152, 235),
    (195, 151, 234),
    (197, 151, 234),
    (198, 150, 233),
    (199, 150, 232),
    (200, 150, 231),
    (201, 149, 230),
    (202, 149, 229),
    (203, 149, 228),
    (204, 148, 227),
    (205, 148, 226),
    (206, 147, 225),
    (207, 147, 224),
    (208, 147, 223),
    (209, 146, 222),
    (210, 146, 221),
    (211, 146, 219),
    (212, 145, 218),
    (213, 145, 217),
    (214, 145, 216),
    (215, 144, 215),
    (216, 144, 214),
    (217, 144, 212),
    (218, 144, 211),
    (219, 143, 210),
    (220, 143, 209),
    (220, 143, 208),
    (221, 142, 206),
    (222, 142, 205),
    (223, 142, 204),
    (224, 142, 203),
    (224, 141, 201),
    (225, 141, 200),
    (226, 141, 199),
    (227, 141, 197),
    (227, 141, 196),
    (228, 140, 195),
    (229, 140, 193),
    (229, 140, 192),
    (230, 140, 190),
    (231, 140, 189),
    (231, 140, 188),
    (232, 139, 186),
    (232, 139, 185),
    (233, 139, 184),
    (234, 139, 182),
    (234, 139, 181),
    (235, 139, 179),
    (235, 139, 178),
    (236, 139, 176),
    (236, 139, 175),
    (236, 139, 174),
    (237, 138, 172),
]
color = [
    "black",
    "red",
    "green",
    "yellow",
    "blue",
    "magenta",
    "cyan",
    "white",
    "lightblack",
    "lightred",
    "lightgreen",
    "lightyellow",
    "lightblue",
    "lightmagenta",
    "lightcyan",
    "lightwhite",
]


def get_terminal_width() -> int:
    return shutil.get_terminal_size().columns


def get_color_default(angle: int) -> tuple:
    return rainbow_color[angle % 360]


class print_rgb:
    def __init__(self):
        self.angle = 0

    def __call__(
        self,
        *values: object,
        foreground_color: list | tuple | None = None,
        background_color: list | tuple | None = None,
        basic_color: dict | None = None,
        sep: str = " ",
        rainbow: bool = False,
        angle_mode: Literal["inner", "init", "random"] = "random",
        end: str = "\n",
        file: TextIO | None = None,
        get_color: types.FunctionType | None = None,
        flush: Literal[False] = False,
        swap_fbc: bool = False,
    ) -> None:
        get_color = get_color_default if get_color is None else get_color
        if not rainbow:
            colored_text = ""
            if foreground_color or background_color:
                esc = []
                if foreground_color:
                    esc.append(f'38;2;{";".join(map(str, foreground_color))}')
                if background_color:
                    esc.append(f'48;2;{";".join(map(str, background_color))}')
                color_code = ";".join(esc)
                if swap_fbc:
                    colored_text = (
                        f"\033[7m\033[{color_code}m{sep.join(map(str, values))}\033[0m"
                    )
                else:
                    colored_text = (
                        f"\033[{color_code}m{sep.join(map(str, values))}\033[0m"
                    )
            elif basic_color:
                esc = []
                if "background_color" in basic_color:
                    if (
                        color.index(
                            basic_color.get("background_color", "black").lower()
                        )
                        < 8
                    ):
                        esc.append(
                            f'4{color.index(basic_color.get("background_color","black").lower())}'
                        )
                    else:
                        esc.append(
                            f'10{color.index(basic_color.get("background_color","black").lower()) - 8}'
                        )
                if "foreground_color" in basic_color:
                    if (
                        color.index(
                            basic_color.get("foreground_color", "white").lower()
                        )
                        < 8
                    ):
                        esc.append(
                            f'3{color.index(basic_color.get("foreground_color","white").lower())}'
                        )
                    else:
                        esc.append(
                            f'9{color.index(basic_color.get("foreground_color","white").lower()) - 8}'
                        )
                colored_text = (
                    f'\033[{";".join(esc)}m{sep.join(map(str, values))}\033[0m'
                )
            else:
                colored_text=sep.join(values)
            print(colored_text, end=end, file=file, flush=flush)
        else:
            if foreground_color or background_color:
                print(
                    "\033[38;2;255;0;0mError,You can't print with rainbow and other color angle_mode in the same time.\033[0m"
                )
            elif basic_color:
                print(
                    "\033[38;2;255;0;0mError,You can't print with rainbow and other basic color mode in the same time.\033[0m"
                )
            else:
                text = f"{sep.join(map(str, values))}"
                if angle_mode == "inner":
                    x, y, k = (0, 0, 0)
                    temp_string = ""
                    escapt_char_index = 0
                    escape_character = 1
                    for current_char in text:
                        escapt_char_index += 1
                        if current_char == "":
                            temp_string += current_char
                            k = 1
                        elif k == 1:
                            if current_char == "[":
                                temp_string += current_char
                                k = 2
                                try:
                                    if (
                                        text[escapt_char_index : escapt_char_index + 3]
                                        in [
                                            "30m",
                                            "31m",
                                            "32m",
                                            "33m",
                                            "34m",
                                            "35m",
                                            "36m",
                                            "37m",
                                            "90m",
                                            "91m",
                                            "92m",
                                            "93m",
                                            "94m",
                                            "95m",
                                            "96m",
                                            "97m",
                                            "40m",
                                            "41m",
                                            "42m",
                                            "43m",
                                            "44m",
                                            "45m",
                                            "46m",
                                            "47m",
                                        ]
                                    ) or (
                                        text[escapt_char_index : escapt_char_index + 4]
                                        in [
                                            "100m",
                                            "101m",
                                            "102m",
                                            "103m",
                                            "104m",
                                            "105m",
                                            "106m",
                                            "107m",
                                        ]
                                    ):
                                        escape_character = 0
                                    else:
                                        escape_character = 1
                                except:
                                    pass
                            else:
                                temp_string = current_char
                                x += 1
                                if x == get_terminal_width():
                                    x = 0
                                    y += 1
                                if escape_character:
                                    self(
                                        current_char,
                                        foreground_color=get_color(
                                            self.angle + x * 5 + y * 7
                                        ),
                                        end="",
                                        file=file,
                                        swap_fbc=swap_fbc,
                                    )
                                else:
                                    print(current_char, end="", file=file)
                                k = 0
                        elif k > 1:
                            if 64 <= ord(current_char) <= 126:
                                temp_string += current_char
                                if escape_character:
                                    self(
                                        temp_string,
                                        foreground_color=get_color(
                                            self.angle + x * 5 + y * 7
                                        ),
                                        end="",
                                        file=file,
                                        swap_fbc=swap_fbc,
                                    )
                                else:
                                    print(current_char, end="", file=file)
                                temp_string = ""
                                k = 0
                            else:
                                temp_string += current_char
                        elif current_char != "\n":
                            if current_char != " ":
                                if escape_character:
                                    self(
                                        current_char,
                                        foreground_color=get_color(
                                            self.angle + x * 5 + y * 7
                                        ),
                                        end="",
                                        file=file,
                                        swap_fbc=swap_fbc,
                                    )
                                else:
                                    print(current_char, end="", file=file)
                            else:
                                if escape_character:
                                    self(
                                        current_char,
                                        foreground_color=get_color(
                                            self.angle + x * 5 + y * 7
                                        ),
                                        end="",
                                        file=file,
                                    )
                                else:
                                    print(current_char, end="", file=file)
                            x += 1
                            if x == get_terminal_width():
                                x = 0
                                y += 1
                        else:
                            x = 1
                            y += 1
                            print("", file=file)
                    self.angle += y * 7 + 14
                elif angle_mode == "init":
                    x, y, k = (0, 0, 0)
                    temp_string = ""
                    escapt_char_index = 0
                    escape_character = 1
                    for current_char in text:
                        escapt_char_index += 1
                        if current_char == "":
                            temp_string += current_char
                            k = 1
                        elif k == 1:
                            if current_char == "[":
                                temp_string += current_char
                                k = 2
                                try:
                                    if (
                                        text[escapt_char_index : escapt_char_index + 3]
                                        in [
                                            "30m",
                                            "31m",
                                            "32m",
                                            "33m",
                                            "34m",
                                            "35m",
                                            "36m",
                                            "37m",
                                            "90m",
                                            "91m",
                                            "92m",
                                            "93m",
                                            "94m",
                                            "95m",
                                            "96m",
                                            "97m",
                                            "40m",
                                            "41m",
                                            "42m",
                                            "43m",
                                            "44m",
                                            "45m",
                                            "46m",
                                            "47m",
                                        ]
                                    ) or (
                                        text[escapt_char_index : escapt_char_index + 4]
                                        in [
                                            "100m",
                                            "101m",
                                            "102m",
                                            "103m",
                                            "104m",
                                            "105m",
                                            "106m",
                                            "107m",
                                        ]
                                    ):
                                        escape_character = 0
                                    else:
                                        escape_character = 1
                                except:
                                    pass
                            else:
                                temp_string = current_char
                                x += 1
                                if x == get_terminal_width():
                                    x = 0
                                    y += 1
                                if escape_character:
                                    self(
                                        current_char,
                                        foreground_color=get_color(x * 5 + y * 7),
                                        end="",
                                        file=file,
                                        swap_fbc=swap_fbc,
                                    )
                                else:
                                    print(current_char, end="", file=file)
                                k = 0
                        elif k > 1:
                            if 64 <= ord(current_char) <= 126:
                                temp_string += current_char
                                if escape_character:
                                    self(
                                        temp_string,
                                        foreground_color=get_color(x * 5 + y * 7),
                                        end="",
                                        file=file,
                                        swap_fbc=swap_fbc,
                                    )
                                else:
                                    print(current_char, end="", file=file)
                                temp_string = ""
                                k = 0
                            else:
                                temp_string += current_char
                        elif current_char != "\n":
                            if current_char != " ":
                                if escape_character:
                                    self(
                                        current_char,
                                        foreground_color=get_color(x * 5 + y * 7),
                                        end="",
                                        file=file,
                                        swap_fbc=swap_fbc,
                                    )
                                else:
                                    print(current_char, end="", file=file)
                            else:
                                if escape_character:
                                    self(
                                        current_char,
                                        foreground_color=get_color(x * 5 + y * 7),
                                        end="",
                                        file=file,
                                    )
                                else:
                                    print(current_char, end="", file=file)
                            x += 1
                            if x == get_terminal_width():
                                x = 0
                                y += 1
                        else:
                            x = 1
                            y += 1
                            print("", file=file)
                    self.angle += y * 7 + 14
                else:
                    x, y, k = (0, 0, 0)
                    angle = random.randint(0, 359)
                    temp_string = ""
                    escapt_char_index = 0
                    escape_character = 1
                    for current_char in text:
                        escapt_char_index += 1
                        if current_char == "":
                            temp_string += current_char
                            k = 1
                        elif k == 1:
                            if current_char == "[":
                                temp_string += current_char
                                k = 2
                                try:
                                    if (
                                        text[escapt_char_index : escapt_char_index + 3]
                                        in [
                                            "30m",
                                            "31m",
                                            "32m",
                                            "33m",
                                            "34m",
                                            "35m",
                                            "36m",
                                            "37m",
                                            "90m",
                                            "91m",
                                            "92m",
                                            "93m",
                                            "94m",
                                            "95m",
                                            "96m",
                                            "97m",
                                            "40m",
                                            "41m",
                                            "42m",
                                            "43m",
                                            "44m",
                                            "45m",
                                            "46m",
                                            "47m",
                                        ]
                                    ) or (
                                        text[escapt_char_index : escapt_char_index + 4]
                                        in [
                                            "100m",
                                            "101m",
                                            "102m",
                                            "103m",
                                            "104m",
                                            "105m",
                                            "106m",
                                            "107m",
                                        ]
                                    ):
                                        escape_character = 0
                                    else:
                                        escape_character = 1
                                except:
                                    pass
                            else:
                                temp_string = current_char
                                x += 1
                                if x == get_terminal_width():
                                    x = 0
                                    y += 1
                                if escape_character:
                                    self(
                                        current_char,
                                        foreground_color=get_color(
                                            angle + x * 5 + y * 7
                                        ),
                                        end="",
                                        file=file,
                                        swap_fbc=swap_fbc,
                                    )
                                else:
                                    print(current_char, end="", file=file)
                                k = 0
                        elif k > 1:
                            if 64 <= ord(current_char) <= 126:
                                temp_string += current_char
                                if escape_character:
                                    self(
                                        temp_string,
                                        foreground_color=get_color(
                                            angle + x * 5 + y * 7
                                        ),
                                        end="",
                                        file=file,
                                        swap_fbc=swap_fbc,
                                    )
                                else:
                                    print(temp_string, end="", file=file)
                                temp_string = ""
                                k = 0
                            else:
                                temp_string += current_char
                        elif current_char != "\n":
                            if current_char != " ":
                                if escape_character:
                                    self(
                                        current_char,
                                        foreground_color=get_color(
                                            angle + x * 5 + y * 7
                                        ),
                                        end="",
                                        file=file,
                                        swap_fbc=swap_fbc,
                                    )
                                else:
                                    print(current_char, end="", file=file)
                            else:
                                if escape_character:
                                    self(
                                        current_char,
                                        foreground_color=get_color(
                                            angle + x * 5 + y * 7
                                        ),
                                        end="",
                                        file=file,
                                    )
                                else:
                                    print(current_char, end="", file=file)
                            x += 1
                            if x == get_terminal_width():
                                x = 0
                                y += 1
                        else:
                            x = 1
                            y += 1
                            print("", file=file)
                print(end, end="", file=file)

